#include <stdio.h>
#include <stdlib.h>
#include "../head/linkedList.h"
#include <string.h>
#include "linkedList.c"
void screen()
{
	printf("------------------------------------------------------------------\n");
	printf("|***********What do you want to do?(start wiht 1)     ***********|\n");
	printf("|***********1.creat a list                            ***********|\n");
	printf("|***********2.insert a number                         ***********|\n");
	printf("|***********3.delete a number                         ***********|\n");
	printf("|***********4.print the list                          ***********|\n");
	printf("|***********5.find a data in the list                 ***********|\n");
	printf("|***********6.destroy the list                        ***********|\n");
	printf("|***********7.judge whether the linked list is looped ***********|\n");
	printf("|***********8.find the midle node                     ***********|\n");
	printf("|***********9.reverse the list                        ***********|\n");
	printf("|***********10.exit the software                      ***********|\n");
	printf("|***********11.print this menu again                  ***********|\n");
	printf("------------------------------------------------------------------\n");

}
int judge(int t){
	printf("what do you want to do next?Please choose:");
				scanf("%d",&t);
				while(t<1||t>11){
					printf("ERROR input!Please input again:");
					scanf("%d",&t);
				}
	return t;
}
void getInput(LNode *num){
	printf("Please input data:");
	scanf("%d",&num->data);
}
void adddata(LNode **list){
	LNode *add,*tem;
	add=(LinkedList)malloc(sizeof(LNode));
	if(add==NULL){
		printf("ERROR!\n");
		exit(1);
	}
	getInput(add);
	
	
		tem=*list;
		while(tem->next!=NULL){
			tem=tem->next;
		}
		tem->next=add;
		add->next=NULL;
	

}
void visit(ElemType e); 
int main(){
	int i,j,t,x;LinkedList L;LNode *info,temp,*mid,*last;ElemType e;char ch;
	screen();
	scanf("%d",&t);
	while(t<1||t>11){
		printf("ERROR input!Please input agian:");
		scanf("%d",&t);
	}
	while(t>0&&t<12){
		switch(t){
			case 1:
				InitList(&L);
				while(1){
					printf("do you want to input data(Y/N)?:");
					do{
						ch=getchar();
					}while(ch!='Y'&&ch!='N');
					if(ch=='Y')
					{
						adddata(&L);
					}
					else {
						break;
					}
				}
				printf("OK!\n");
				t=judge(t);
				break;
			case 2:
				printf("What data do you want to insert?:");
				scanf("%d",&i);
				printf("which node do you want to insert after(if you want to insert it at the beginnig, please input 0):");
				scanf("%d",&j);
				t=0;
				last=L;
				while(t<j){
					last=last->next;
					t++;
				}
				
		    	info=(LinkedList)malloc(sizeof(LNode));
				info->data=i;
				InsertList(last,info) ;
				printf("INSERT SUCCESS!\n");
				t=judge(t);
				break;
			case 3:
				printf("which data do you want to delete:");
				scanf("%d",&i);
				last=L;
				j=SearchList(L, i);
				if(j==0){
				printf("can't find %d in this list\n",i);
				t=judge(t);
				break;
			}
				while(last->next->data!=i){
					last=last->next;
				}
				DeleteList(last,&e);
				printf("DELETE SUCCESS!\n");
				t=judge(t);
				break;
			case 4:
				printf("Here is the list:\n");
				TraverseList(L,visit);
				printf("\n"); 
				t=judge(t);
				break;
			case 5:
				printf("which data do you want to find?\n");
				scanf("%d",&i);
				j=SearchList(L, i);
				if(j==0) printf("%d isn't' exit.\n",i);
				if(j==1) printf("%d is exit\n",i);
				t=judge(t);
				break;
			case 6:
				DestroyList(&L);
				printf("DESTROY SUCCESS!\n");
				t=judge(t);
				break;
			case 7:
				j=IsLoopList(L);
				if(j==1) printf("the list is looped.\n");
				else printf("the list isn'r looped.\n'");
				t=judge(t);
				break;
			case 8:
				printf("the midle node is:");
				mid=FindMidNode(&L);
				printf("%d\n",mid->data);
				t=judge(t);
				break;
			case 9:
				ReverseList(&L);
				printf("REVERSE SUCCESS!\n");
				t=judge(t);
				break;
			case 10:
				printf("Thanks for your use\nHave a nice day!\nBye Bye ^_^\n");
				return 0;
			case 11:
				screen();
				t=judge(t);
				break;
		}
	}
return 0;
}
