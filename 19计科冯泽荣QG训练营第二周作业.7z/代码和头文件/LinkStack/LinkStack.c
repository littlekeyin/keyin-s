#include "../head/LinkStack.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 

//��ջ
Status initLStack(LinkStack *s)//��ʼ��ջ
{
	 s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	 if(!s->top) return ERROR;
	 s->top=NULL;
	 s->count=0;
	 return SUCCESS; 
}
Status isEmptyLStack(LinkStack *s)//�ж�ջ�Ƿ�Ϊ��{
{
	if(s->top==NULL) 
	return SUCCESS; 
	return ERROR; 
}
Status getTopLStack(LinkStack *s,ElemType *e)//�õ�ջ��Ԫ��
{
	if(isEmptyLStack(s)==SUCCESS) {
		printf("ջΪ�ա�\n");
		return ERROR;
	}
	*e=s->top->data;
	return SUCCESS;
}
Status clearLStack(LinkStack *s)//���ջ
{
	ElemType *data;
	while(isEmptyLStack(s)==ERROR){
	popLStack(s,data);
	}
	
	return SUCCESS;
}
Status destroyLStack(LinkStack *s)//����ջ
{
	LinkStackPtr q,p;
	int i;
	p=s->top;
	for(i=s->count;i>0;i--){
		q=p->next;
		free(p);
		p=q;
	}
	s->count=0;
	s->top=NULL;
	free(s);
	s=NULL; 
	return SUCCESS;
}
Status LStackLength(LinkStack *s,int *length)//���ջ����
{
	if(isEmptyLStack(s)==SUCCESS) {
		printf("ջΪ�ա�\n");
		return ERROR;
	}
	*length=s->count;
	return SUCCESS;
}
Status pushLStack(LinkStack *s,ElemType data)//��ջ
{
	if(s==NULL) {
		printf("���ȳ�ʼ��ջ��\n");
		return ERROR;
	}
	LinkStackPtr p=(LinkStackPtr)malloc(sizeof(StackNode));
	if(!p) {
		printf("�ڴ����ʧ���ˣ�\n");
		return ERROR; 
	}
	p->data=data;
	p->next=s->top;
	s->top=p;
	s->count++;
	return SUCCESS;
}
Status popLStack(LinkStack *s,ElemType *data)//��ջ
{
	if(isEmptyLStack(s)==SUCCESS) {
		printf("ջΪ�ա�\n");
		return ERROR;
	}
	LinkStackPtr temp=s->top;
	*data=temp->data;
	s->top=temp->next;
	free(temp);
	s->count--;
	return SUCCESS; 
}
